/**
 * Route logic as pure functions: query/body in, status+body out. The HTTP
 * shell (index.ts) owns req/res mechanics; everything testable lives here.
 */
import { type CopyFilesSeams } from './copy-files.js';
import { type DirExists, type ExcludeSeams, type Exec } from './git.js';
import type { CreateBranchResult, CreateWorktreeResult, EnsureDirectoryResult, FetchResult, GroupWorkspacesResult, InspectWorktreeResult, PathExistsResult, PurgeDirectoryResult, RemoveWorktreeResult, RepoStatus, RouteError, SwitchResult, UpdateResult, WorktreesAllResult } from './wire.js';
/** Everything the handlers need from the host half. */
export interface RouteDeps {
    exec: Exec;
    /** The settings-resolved rootDir (absent/blank = the default location). */
    sectionRootDir: () => string | undefined;
    /** Whether a worktree creation syncs the remotes first (absent = off). */
    sectionFetchBeforeCreate: () => boolean | undefined;
    /** Post-create configuration files to copy when .worktreeinclude is absent. */
    sectionPostCreateCopyFiles?: () => string[] | undefined;
    /** User home directory seam. */
    home: () => string;
    /** `$DSH_HOME` environment value seam. */
    envHome: () => string | undefined;
    /** Worktree-registration existence seam (tests substitute). */
    dirExists?: DirExists;
    /** Local-ignore write seams (tests substitute). */
    excludeSeams?: ExcludeSeams;
    /** Post-create file copy seams (tests substitute). */
    copyFilesSeams?: CopyFilesSeams;
    /** Directory probe seam over fs.stat (true = exists AND is a directory);
     * tests substitute. */
    statDirectory?: (path: string) => Promise<boolean>;
    /** Recursive mkdir seam (fs.mkdir recursive); tests substitute. */
    mkdirRecursive?: (path: string) => Promise<void>;
    /** One-level directory listing seam (fs.readdir with dirents); tests
     * substitute. */
    listDir?: (path: string) => Promise<string[]>;
    /** Recursive force rm seam (fs.rm with retries); tests substitute. */
    rmRecursive?: (path: string) => Promise<void>;
}
/** Real fs-backed one-level directory listing (names only). Plain FILES are
 * filtered out — the storage root can carry strays (a legacy settings.json
 * was seen in the wild), and the scan lists worktree SLOTS, not entries. */
export declare function fsListDir(path: string): Promise<string[]>;
/** Real fs-backed directory probe: exists and is a directory. */
export declare function fsStatDirectory(path: string): Promise<boolean>;
/** Real fs-backed recursive mkdir. */
export declare function fsMkdirRecursive(path: string): Promise<void>;
/** One route outcome: HTTP status plus the JSON body. */
export interface RouteOutcome {
    status: number;
    body: RepoStatus | CreateWorktreeResult | SwitchResult | CreateBranchResult | FetchResult | UpdateResult | GroupWorkspacesResult | InspectWorktreeResult | RemoveWorktreeResult | PathExistsResult | EnsureDirectoryResult | WorktreesAllResult | PurgeDirectoryResult | RouteError;
}
/**
 * POST /group — git belonging facts for a batch of workspace directories.
 * Deduplicates, validates, probes in bounded batches, and answers 200 with
 * per-path facts (null for non-repositories); a repository-wide git failure
 * is a per-path null, never a 500 — the sidebar must degrade to flat, not
 * error out.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ paths }`.
 */
export declare function handleGroupWorktrees(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /worktrees-all — git facts for every DIRECT child directory of the two
 * storage locations the plugin has ever used, merged:
 *
 * - legacy: the resolved central storage root (today a read-only historical
 *   location — existing worktrees stay put, `rootDir` still resolves it);
 * - project: `<repo>/.dsh/gitworktree` under every DISTINCT repository root
 *   derived from the caller's registered workspace paths (the current
 *   layout — its path prefix is what the workspace tree nests under).
 *
 * The management dialog's data source (and, through it, the lazy prune's):
 * one scan answers for all repositories at once, orphan directories included
 * (a child that probes as no git repository comes back with null facts
 * rather than being dropped — the dialog shows it as unrecognized). Missing
 * locations answer their half as an empty list; per-child probe failures
 * degrade to null facts, never a 500 — the dialog must render, not error
 * out. Each location that holds more than {@link SCAN_CHILDREN_LIMIT}
 * children answers its first slice, and any truncation marks the whole
 * response `truncated`, so a misconfigured location cannot turn one dialog
 * open into thousands of git spawns.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ workspaces? }`.
 */
export declare function handleWorktreesAll(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/** Real fs-backed recursive force rm (Windows file-lock retries included). */
export declare function fsRmRecursive(path: string): Promise<void>;
/**
 * POST /purge — delete a NON-git directory sitting DIRECTLY inside one of the
 * plugin's two storage layouts: the legacy central root or a repository's
 * `.dsh/gitworktree`. The orphaned leftover a half-failed `worktree remove`
 * can leave behind (git registration and the .git file already gone,
 * contents stranded on disk). Triple-gated: one level below a storage
 * location (resolved forms, same slot boundary as /ensure-directory), a real
 * directory, and NOT a git repository — anything git still recognizes must
 * go through /remove, where the removal carries the session-archive and
 * unregistration half. Deletion is a plain recursive force rm.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export declare function handlePurgeDirectory(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * GET /status 鈥?repository facts for one directory.
 * @param deps - host dependencies.
 * @param path - absolute directory the workspace reports.
 */
export declare function handleStatus(deps: RouteDeps, path: string | undefined): Promise<RouteOutcome>;
/**
 * POST /worktree — create or reuse the worktree for a branch, then report the
 * directory so the client can register it as a workspace. The worktree lands
 * at `<repo>/.dsh/gitworktree/<branch>` (path prefix = repository, so the
 * native workspace tree nests it under its repository automatically); an
 * existing registration for the branch ANYWHERE is reused first (the
 * repository-wide worktree list is location-independent — legacy-central
 * worktrees keep being returned, never duplicated). With `cutout: true` the
 * branch is the CURRENT checkout (occupied by the main worktree, so git
 * refuses to add it): a new branch is cut out of it (`<branch>-wt`, first
 * free `-wt<N>` suffix) and isolated in the fresh worktree instead.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleCreateWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /switch 鈥?in-place branch switch of the main checkout.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleSwitch(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /branch — create a NEW branch. Without `from`, from the queried
 * directory's current checkout (whatever its HEAD points at, detached
 * included), checked out in place. With `from` (a local branch or a remote
 * tracking ref): checked out here too when `checkout` is set
 * (`git switch -c <name> <from>`), created with no checkout touched
 * otherwise (`git branch`) — a create aimed at another branch must not
 * silently move the session's HEAD unless the caller asked for exactly
 * that. Git validates both names; the client pre-flights the same rules
 * and only sends names it already accepts.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleCreateBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /branch-rename — rename a LOCAL branch (`git branch -m`). Runs at the
 * repository root: branch refs are repository-wide and worktree HEADs
 * pointing at the old name follow the ref. Git validates the new name and
 * refuses a target that already exists; both map to 400 through
 * {@link gitFailure}.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleRenameBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /branch-delete — delete a LOCAL branch with the SAFE form
 * (`git branch -d`): git refuses unmerged commits and branches checked out
 * in any worktree, both mapping to 400 through {@link gitFailure}. No
 * force variant — a menu click must never discard commits.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleDeleteBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /fetch 鈥?sync remote-tracking refs for the repository: fetch every
 * remote and prune tracking branches the remotes no longer carry. Pure
 * metadata — the working tree and the current checkout are untouched; the
 * client refetches /status afterwards for the fresh branch list.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleFetch(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /update 鈥?update the CURRENT checkout: fetch every remote, then
 * fast-forward the branch checked out by the queried directory to its
 * upstream. Divergence, a missing upstream, and conflicting working-tree
 * changes all surface as 400 envelopes carrying git's own explanation.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handleUpdate(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /push 鈥?push the branch checked out by the queried directory to its
 * upstream. A missing upstream and a diverged remote surface as 400
 * envelopes carrying git's own explanation; `--force` is never passed.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export declare function handlePush(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /inspect — pre-delete facts for one worktree directory: the
 * uncommitted-file count (those die with the folder) and the checked-out
 * branch's ahead count (kept — the branch ref survives the removal).
 * Deliberately repo-wide neutral: any directory inside a repository answers,
 * so the dialog data stays meaningful even for odd shapes.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export declare function handleInspectWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /remove — delete one linked worktree: git's registration plus the
 * folder in one stroke (`worktree remove`, `--force` past uncommitted
 * changes the dialog already showed). DSH-side cleanup (archiving the
 * workspace's sessions, dropping the workspace registration) is the
 * browser's follow-up, by design: git first, so a refused removal leaves
 * the workspace world untouched.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path, force? }`.
 */
export declare function handleRemoveWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /exists — batch directory-existence probe over plain fs (no git): true
 * per path that exists AND is a directory. The browser gates the
 * register-as-workspace action on this, so a missing folder (deleted, moved,
 * or a corrupted session-header cwd) is answered by THIS route — the DSH
 * workspace API never sees an unregistrable path.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ paths }`.
 */
export declare function handlePathExists(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
/**
 * POST /ensure-directory — recreate a MISSING worktree storage slot
 * (`mkdir -p`). Strictly gated to paths sitting DIRECTLY inside one of the
 * plugin's two storage layouts (the legacy central root, or a repository's
 * `.dsh/gitworktree`): those slots were planned and created by this plugin,
 * so rebuilding the empty folder is self-healing (historical sessions
 * reattach automatically once realpath matches again — DSH keeps the
 * workspace accounting and filters membership by the session header's cwd).
 * Anything else is outside this plugin's territory and is refused, so a
 * corrupted session-header cwd can never be materialized as stray folders.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export declare function handleEnsureDirectory(deps: RouteDeps, body: unknown): Promise<RouteOutcome>;
