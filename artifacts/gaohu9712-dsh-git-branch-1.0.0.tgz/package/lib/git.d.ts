/**
 * Git command wrapper for the host half. All git access goes through one
 * injectable `exec` seam (tests substitute it); every method is plain
 * argument assembly plus porcelain parsing, no ambient state.
 */
import type { BranchEntry, WorktreeEntry, WorkspaceGitFacts } from './wire.js';
/** One process result as the seam reports it. */
export interface ExecResult {
    code: number;
    stdout: string;
    stderr: string;
}
/**
 * Process executor seam. Runs `file args` with cwd set, captures output as
 * UTF-8 text, and never throws — a non-zero exit is a normal result.
 */
export type Exec = (file: string, args: readonly string[], options: {
    cwd: string;
}) => Promise<ExecResult>;
/** Failure of one git invocation: non-zero exit with the stderr text. */
export declare class GitError extends Error {
    readonly args: readonly string[];
    readonly code: number;
    readonly stderr: string;
    constructor(args: readonly string[], code: number, stderr: string);
}
/** Facts the status route assembles: branches, worktrees, repo identity. */
export interface RepoFacts {
    /** Absolute main worktree path (`dirname` of `--git-common-dir`, not the
     * queried directory's `--show-toplevel` — a linked worktree's toplevel
     * dies during `worktree remove`). */
    repoRoot: string;
    /** Main repository directory basename. */
    repoName: string;
    /** The QUERIED directory's own toplevel — the worktree the session
     * actually sits in. Repository-wide commands (branch refs, fetch,
     * worktree registration) run at {@link RepoFacts.repoRoot}; commands that
     * act on the session's own checkout (switch/update/create-and-check-out)
     * run HERE, or a linked-worktree session would silently operate on the
     * main checkout instead. */
    toplevel: string;
    /** Whether the QUERIED directory is the main worktree — see
     * {@link isMainWorktree}. `repoRoot` cannot answer this: it names the main
     * checkout from every worktree by construction. */
    main: boolean;
    /** Branch checked out by the queried directory. */
    currentBranch: string;
    branches: BranchEntry[];
    worktrees: WorktreeEntry[];
}
/** Real executor over node:child_process with a hard timeout. */
export declare function childProcessExec(file: string, args: readonly string[], options: {
    cwd: string;
}): Promise<ExecResult>;
/** Directory-existence seam over the parsed worktree registrations. */
export type DirExists = (path: string) => boolean;
/** Real existence check. */
export declare const fsDirExists: DirExists;
/**
 * Leftover-directory sweeper after `git worktree remove` unregisters but
 * fails the final rmdir (Windows EPERM when a process still has the folder
 * as cwd). `gone` = deleted; `empty` = still there but vacant (cwd hold);
 * `occupied` = still has files — the caller must not pretend removal finished.
 */
export type SweepDir = (path: string) => Promise<'gone' | 'empty' | 'occupied'>;
/** Real leftover sweep: `fs.rm` with Windows EPERM retries, then classify. */
export declare function fsSweepDir(path: string): Promise<'gone' | 'empty' | 'occupied'>;
/**
 * Resolve a directory to repository facts, or undefined outside any git
 * repository (including the `git` binary missing: ENOENT surfaces as a
 * non-zero exit through the seam).
 * @param exec - executor seam.
 * @param path - absolute directory the workspace reports.
 * @param dirExists - existence seam for stale-registration filtering.
 */
export declare function probeRepo(exec: Exec, path: string, dirExists?: DirExists): Promise<RepoFacts | undefined>;
/**
 * Resolve a branch display name against the authoritative branch list of the
 * repository. Exported for the /worktree route's fetch gate: the pre-create
 * remote sync only earns its round trip when the display name is REMOTE-only
 * (a local branch's worktree never consumes fetched refs).
 * @returns the local name plus the tracking remote when the display name is
 * remote-only, or undefined when neither shape exists.
 */
export declare function resolveBranch(exec: Exec, repoRoot: string, branch: string): Promise<{
    local: string;
    remote: string | undefined;
} | undefined>;
/**
 * Create (or reuse) the worktree for one branch.
 *
 * Idempotence: git allows one worktree per checked-out branch, so an existing
 * worktree already on `branch` (compared by local name) is returned unreused.
 * A local branch gets `git worktree add <path> <name>`; a remote-only branch
 * gets a new local twin via `git worktree add <path> -b <name> <remoteRef>`.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param branch - branch display name.
 * @param targetPath - absolute directory to create.
 * @returns the worktree path and whether this call created it.
 */
export declare function addWorktree(exec: Exec, repoRoot: string, branch: string, targetPath: string, dirExists?: DirExists): Promise<{
    path: string;
    created: boolean;
}>;
/**
 * Plan a new branch name to cut out of `base`: `<base>-wt`, or the first
 * `-wt<N>` suffix not already taken (`main` → `main-wt`; if that exists,
 * `main-wt2`, …). One `for-each-ref` pass decides; the worktree folder
 * name derives from the returned name, so the caller should resolve it
 * BEFORE computing the target path. With `folderTaken` given, a name is
 * only free when its storage folder is free too: a leftover folder of a
 * since-deleted branch would otherwise fail `worktree add` with a bare
 * "already exists" — the suffix walk skips it the same way.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param base - base branch local name (or `HEAD` when detached).
 * @param folderTaken - storage-folder occupancy probe (branch name → taken).
 * @returns the free cutout branch name.
 */
export declare function cutoutBranchName(exec: Exec, repoRoot: string, base: string, folderTaken?: (branch: string) => boolean): Promise<string>;
/**
 * Create a worktree on a brand-new branch cut out of `base`: the base is
 * checked out by the main worktree (git forbids a second worktree on it),
 * so the new branch is created from it and checked out in the fresh
 * worktree instead.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param base - base branch local name (`main` or `HEAD`).
 * @param newBranch - the cutout branch name (see {@link cutoutBranchName}).
 * @param targetPath - absolute directory to create.
 */
export declare function addWorktreeCutout(exec: Exec, repoRoot: string, base: string, newBranch: string, targetPath: string): Promise<void>;
/**
 * In-place branch switch of the main checkout. A remote display name relies
 * on git's dwim: `git switch <local>` creates the tracking branch when
 * exactly one remote has it.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param branch - branch display name.
 * @returns the local branch name now checked out.
 */
export declare function switchBranch(exec: Exec, repoRoot: string, branch: string): Promise<string>;
/**
 * Create a NEW branch. Three shapes:
 *
 *   - no `from`: cut from the current checkout and check it out in place
 *     (`git switch -c`) — the cut point is whatever the queried directory's
 *     HEAD points at, so a detached or unborn checkout cuts from the current
 *     commit too. Runs at the queried directory's own toplevel — a session
 *     inside a linked worktree creates and checks out within that worktree,
 *     never the main checkout (the same semantics as {@link switchBranch}).
 *   - `from` without `checkout`: create AT that start point WITHOUT touching
 *     any checkout (`git branch`) — a create aimed at another branch must
 *     not move this session's HEAD.
 *   - `from` with `checkout`: create at the start point AND check it out
 *     here in one stroke (`git switch -c <name> <from>`).
 * @param exec - executor seam.
 * @param cwd - directory whose HEAD the branch is cut from (worktree toplevel).
 * @param name - new branch name (git validates; failures raise GitError).
 * @param from - optional start point; absent keeps the in-place semantics.
 * @param checkout - with `from`, also check the new branch out here.
 * @returns the branch name now created (checked out unless created at a
 * start point with `checkout` false).
 */
export declare function createBranch(exec: Exec, cwd: string, name: string, from?: string, checkout?: boolean): Promise<string>;
/**
 * Rename a LOCAL branch (`git branch -m`): branch refs are repository-wide,
 * so the command runs at the repository root and every worktree HEAD pointing
 * at the old name follows the ref. Git validates the new name and refuses a
 * target that already exists; remote branches are not renameable (not ours).
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param name - branch to rename.
 * @param newName - the new local name.
 * @returns the new name.
 */
export declare function renameBranch(exec: Exec, repoRoot: string, name: string, newName: string): Promise<string>;
/**
 * Delete a LOCAL branch (`git branch -d`, the SAFE form): git refuses a
 * branch with unmerged commits ("not fully merged") and one checked out in
 * any worktree — both caller-side state, mapped to 400 by the route. No
 * `-D` force variant on purpose: a menu click must never discard commits
 * (the terminal is the place for deliberate force-deletes). Runs at the
 * repository root; remote branches are not ours to delete.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param name - branch to delete.
 * @returns the name of the branch that was deleted.
 */
export declare function deleteBranch(exec: Exec, repoRoot: string, name: string): Promise<string>;
/**
 * Sync remote-tracking refs: fetch every remote and prune tracking branches
 * the remotes no longer carry (the CLI equivalent of IDEA's "synchronize
 * remote branches"). Pure metadata — the working tree, local branches, and
 * the current checkout are untouched; a slow network surfaces through the
 * executor's hard timeout as a GitError.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory (fetch is repository-wide).
 */
export declare function fetchAll(exec: Exec, repoRoot: string): Promise<void>;
/** Outcome of {@link updateBranch}: the branch touched and whether it moved. */
export interface UpdateOutcome {
    branch: string;
    updated: boolean;
}
/**
 * Update the CURRENT checkout: fetch every remote, then fast-forward the
 * branch checked out by `cwd` to its upstream (`@{u}`) — IDEA's "update
 * selected branch" in its default merge mode. Deliberately `--ff-only`:
 * a diverged local branch refuses rather than silently rebase/merge, and
 * uncommitted working-tree changes are git's own call to reject — the
 * plugin never stashes behind the user's back. Runs at the queried
 * directory's own toplevel, so a linked-worktree session updates the
 * branch ITS worktree holds.
 * @param exec - executor seam.
 * @param cwd - directory whose checked-out branch is updated.
 * @returns the branch name and whether HEAD actually moved (false = the
 * upstream already contained it).
 */
export declare function updateBranch(exec: Exec, cwd: string): Promise<UpdateOutcome>;
/** Outcome of {@link pushBranch}: the branch touched and whether it moved. */
export interface PushOutcome {
    branch: string;
    pushed: boolean;
}
/**
 * Push the branch checked out by `cwd` to its upstream (`@{u}`) — the
 * counterpart of {@link updateBranch}. Deliberately a bare `git push`: the
 * branch must already have an upstream (a no-upstream branch refuses with
 * git's own message rather than silently picking one), and `--force` is
 * never passed — a diverged remote refuses rather than losing commits.
 * Runs at the queried directory's own toplevel, so a linked-worktree
 * session pushes the branch ITS worktree holds.
 * @param exec - executor seam.
 * @param cwd - directory whose checked-out branch is pushed.
 * @returns the branch name and whether HEAD actually moved on the remote
 * (false = the upstream already contained everything).
 */
export declare function pushBranch(exec: Exec, cwd: string): Promise<PushOutcome>;
/** Guard for route inputs: a non-empty absolute directory path. */
export declare function isAbsoluteDir(value: string): boolean;
/** Pre-delete facts of one worktree directory, for the remove-confirm dialog. */
export interface WorktreeInspect {
    /** Uncommitted-change file rows (`git status --porcelain` line count). */
    dirty: number;
    /** Commits ahead of the branch's upstream; undefined when no upstream. */
    ahead: number | undefined;
}
/**
 * Inspect one worktree directory for removal: how many files carry
 * uncommitted changes (those ARE lost with the folder), and how many commits
 * the checked-out branch leads its upstream by (informational only — the
 * branch ref survives `worktree remove`, so those are kept).
 * @param exec - executor seam.
 * @param worktreePath - the worktree directory (absolute).
 */
export declare function inspectWorktree(exec: Exec, worktreePath: string): Promise<WorktreeInspect>;
/**
 * Remove one linked worktree: `git worktree remove` deletes the folder and
 * the registration in one stroke. A stale registration (folder already gone
 * behind git's back) resolves through `worktree prune` instead — the outcome
 * the user asked for either way, which keeps the route idempotent.
 * @param exec - executor seam.
 * @param repoRoot - main worktree directory.
 * @param worktreePath - the linked worktree directory to delete (absolute).
 * @param force - pass `--force` past uncommitted changes.
 * @param dirExists - existence seam for the stale-registration branch.
 * @param sweepDir - leftover rmdir after git unregisters but the OS holds the
 * folder (Windows Permission denied on the empty directory).
 * @returns the path plus whether only a stale registration was pruned.
 * @throws GitError for the main worktree, an unregistered path, or a refused
 * removal (git's own stderr verbatim).
 */
export declare function removeWorktree(exec: Exec, repoRoot: string, worktreePath: string, force: boolean, dirExists?: DirExists, sweepDir?: SweepDir): Promise<{
    path: string;
    pruned: boolean;
}>;
/**
 * Lightweight git belonging probe for ONE workspace directory: the three
 * facts the sidebar grouping needs and nothing else (no branch list, no
 * worktree list — {@link probeRepo} stays the full-facts path for the chip).
 *
 * All three facts come from ONE `git rev-parse` invocation: the sidebar
 * probes every registered workspace on each mount, and on Windows every git
 * call is a process spawn, so three sequential spawns per directory made the
 * startup probe cost scale with the workspace count directly. `rev-parse`
 * evaluates each flag in turn and prints one line per answer, so
 * `--show-toplevel`, `--git-common-dir`, and `--abbrev-ref HEAD` fold into a
 * single process.
 *
 * `repoRoot` — the grouping key — is derived from `--git-common-dir`, which
 * names the SHARED `<repo>/.git` from every worktree of the repository: the
 * main checkout reports it directly, a linked worktree reports the path back
 * to it. Both therefore resolve to the same repository root and group
 * together, wherever the linked folder physically lives.
 * `main` is decided without `worktree list`: a directory is the main worktree
 * exactly when its own toplevel holds that shared .git.
 * `branch` uses `--abbrev-ref HEAD`, whose detached/unborn output is git's
 * synthetic `HEAD` — normalized to null HERE so no consumer downstream ever
 * string-compares against it (the same contract the old `branch
 * --show-current` empty output mapped to).
 * @param exec - executor seam.
 * @param path - absolute directory the workspace reports.
 * @returns the facts, or undefined outside any git repository (a missing git
 * binary surfaces the same way — a non-zero exit through the seam).
 */
export declare function probeWorkspaceGit(exec: Exec, path: string): Promise<WorkspaceGitFacts | undefined>;
/** The one local-ignore rule the project-internal worktree layout needs.
 * Exactly this pattern — NOT `/.dsh/` — so project-level `.dsh/` files a user
 * may want to commit stay trackable. */
export declare const WORKTREE_EXCLUDE_RULE = "/.dsh/gitworktree/";
/** fs seams for {@link appendWorktreeExclude}; tests substitute. */
export interface ExcludeSeams {
    /** Whole file as UTF-8 text; a missing file reads as '' (the rule is
     * simply not there yet). */
    readFile: (path: string) => Promise<string>;
    /** Append text to the end of the file, creating it when missing. */
    appendFile: (path: string, text: string) => Promise<void>;
    /** Recursive mkdir for the `info` directory (git init ships it; a stripped
     * or hand-moved clone may not). */
    mkdir: (path: string) => Promise<void>;
}
/** Real fs-backed seams. */
export declare const fsExcludeSeams: ExcludeSeams;
/**
 * Idempotently add {@link WORKTREE_EXCLUDE_RULE} to the repository's local
 * ignore file (`<repo>/.git/info/exclude`, reachable from every worktree
 * because it lives in the SHARED git dir): the git-blessed place for rules
 * that must stay private to this clone — never committed, never cloned.
 *
 * The write never blocks a worktree creation (the folder cannot be rolled
 * back once built), so a failure is returned as text for the response to
 * carry, not thrown. Idempotent by full-content line match: an absent rule
 * is appended behind a newline guard so it never glues onto the user's last
 * line; an existing rule — or any pre-existing content — is left untouched.
 * @param seams - fs seams (tests substitute).
 * @param repoRoot - the repository's main worktree directory.
 * @returns undefined on success (or the rule already being present); the
 * failure text otherwise.
 */
export declare function appendWorktreeExclude(seams: ExcludeSeams, repoRoot: string): Promise<string | undefined>;
