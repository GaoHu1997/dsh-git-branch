/**
 * dsh-git-branch host half. Exposes volatile configuration fields projected
 * through the settings service (the `git-worktree` profile entry in the active
 * dsh profile) and — while a webServer service exists — the HTTP routes the
 * browser half fetches. Config edits persist into the profile patch and take
 * effect live via the loader.
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-git-branch";
export declare const inject: never[];
export interface Config {
    /** Worktree storage root; defaults to `$DSH_HOME/gitworktree` (`~/.dsh/gitworktree`). */
    rootDir?: Volatile<string | undefined> | string;
    /** Sidebar git grouping on/off; absent = on (the composition-entry layer's default). */
    groupSidebar?: Volatile<boolean> | boolean;
    /** Fetch every remote before creating a worktree; absent = off. A failed
     * fetch never blocks the creation (see the /worktree route). */
    fetchBeforeCreate?: Volatile<boolean> | boolean;
    /** Prune stale worktrees lazily after each creation; absent = off. */
    autoPruneWorktrees?: Volatile<boolean> | boolean;
    /** Global cap the lazy prune trims down to (valid git worktrees only);
     * absent = 30. */
    keepWorktrees?: Volatile<number> | number;
    /** Post-create configuration files to copy when .worktreeinclude is absent;
     * absent = none. */
    postCreateCopyFiles?: Volatile<string[]> | string[];
}
/** The shipped prune cap (whole storage root, valid git worktrees only). */
export declare const KEEP_WORKTREES_DEFAULT = 30;
/**
 * Cordis resolves the composition entry's config through this schema before
 * `apply` runs. In dsh 0.1.7+, fields marked with `.volatile()` are projected
 * by the settings service into live configuration forms.
 */
export declare const Config: z;
/** Reject stale or misspelled config keys before defaults can hide them. */
export declare function validateConfig(config: Config): void;
/**
 * The prune cap must be an integer >= 1: 0 would read as "create then
 * immediately self-delete" (the fresh worktree is excluded, but every other
 * one dies on the next creation), a fraction cannot count directories.
 * Absent = the shipped default, which passes.
 */
export declare function validateKeepWorktrees(value: number | undefined): void;
/** The settings namespace this plugin serves; its browser card spells the same string. */
export declare const GIT_WORKTREE_NS = "git-worktree";
/** The settings-facing subset of the config: the worktree storage root, the
 * sidebar grouping switch, and the create/prune behavior switches. */
export interface SectionConfig {
    /** Worktree storage root; absent/blank selects `$DSH_HOME/gitworktree`. */
    rootDir?: string;
    /** Whether the sidebar groups same-repository workspaces; absent = on. */
    groupSidebar?: boolean;
    /** Fetch every remote before creating a worktree; absent = off. */
    fetchBeforeCreate?: boolean;
    /** Prune stale worktrees lazily after each creation; absent = off. */
    autoPruneWorktrees?: boolean;
    /** Global cap the lazy prune trims down to; absent = 30. */
    keepWorktrees?: number;
    /** Post-create configuration files to copy when .worktreeinclude is absent. */
    postCreateCopyFiles?: string[];
}
/** The section-shaped view of a config: absent keys stay absent
 * (`exactOptionalPropertyTypes`) except the switches, which spell their
 * shipped defaults so a user-layer unset can always fall back to them. */
export declare function sectionOf(config: Config): SectionConfig;
/**
 * Plugin apply: mount the settings presentation policy and HTTP routes on any
 * webServer that comes and goes.
 * @param ctx - host cordis context.
 * @param config - the composition entry config.
 */
export declare function apply(ctx: Context, config?: Config): void;
