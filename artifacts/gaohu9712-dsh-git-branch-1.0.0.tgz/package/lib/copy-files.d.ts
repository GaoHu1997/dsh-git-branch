/**
 * Post-create configuration file copying: copies untracked local files
 * declared in `.worktreeinclude` (or fallback config) from the main worktree
 * to a fresh worktree directory.
 */
/** One failed copy record with error details. */
export interface CopyFailure {
    file: string;
    error: string;
}
/** Pure I/O seams for file reading, existence probe, directory creation, and copying. */
export interface CopyFilesSeams {
    /** Read file as UTF-8; null if missing (ENOENT). */
    readFile?: (path: string) => Promise<string | null>;
    /** Check whether a file or directory exists. */
    exists: (path: string) => Promise<boolean>;
    /** Copy file from src to dest. */
    copyFile: (src: string, dest: string) => Promise<void>;
    /** Recursive mkdir. */
    mkdir: (path: string) => Promise<void>;
}
/** Real fs-backed seams. */
export declare const fsCopyFilesSeams: CopyFilesSeams;
/**
 * Parse `.worktreeinclude` content: line-by-line exact relative paths.
 * Skips empty lines and lines starting with `#`. MVP has no glob expansion
 * or `!` negation support.
 */
export declare function parseWorktreeInclude(content: string): string[];
/**
 * Validate that a path is a safe relative path.
 * Rejects empty paths, absolute paths (both POSIX and Windows shapes),
 * and any path traversal containing `..` segments.
 */
export declare function isSafeRelativePath(relPath: string): boolean;
/**
 * Copy declared files from main worktree (repoRoot) to targetPath.
 * - Missing source files are silently skipped.
 * - Existing destination files are not overwritten.
 * - Parent directories are created recursively.
 * - Unsafe paths and copy errors are collected into failures without throwing.
 */
export declare function copyWorktreeFiles(files: readonly string[], repoRoot: string, targetPath: string, seams?: CopyFilesSeams): Promise<CopyFailure[]>;
/**
 * Format copy failures into a single warning message for the client toast.
 */
export declare function formatCopyWarning(failures: readonly CopyFailure[]): string | undefined;
export interface RunCopyDeps {
    sectionPostCreateCopyFiles?: () => string[] | undefined;
    copyFilesSeams?: CopyFilesSeams;
}
/**
 * Coordinate post-create copying after a fresh worktree is created:
 * 1. Try reading `<repoRoot>/.worktreeinclude`.
 * 2. If present, parse it (fully overrides fallback, even if empty).
 * 3. If absent, fallback to `sectionPostCreateCopyFiles`.
 * 4. Perform copying and return formatted copyWarning if any failures occur.
 */
export declare function runPostCreateCopy(deps: RunCopyDeps, repoRoot: string, targetPath: string): Promise<string | undefined>;
